'use strict'
const modern = require('minimatch-modern')
function callable(api) {
  const native = typeof api === "function" ? api : api.minimatch
  const match = (path, pattern, options) => native(path, pattern, options)
  Object.assign(match, api)
  match.defaults = options => callable(native.defaults(options))
  return match
}
module.exports = callable(modern)
