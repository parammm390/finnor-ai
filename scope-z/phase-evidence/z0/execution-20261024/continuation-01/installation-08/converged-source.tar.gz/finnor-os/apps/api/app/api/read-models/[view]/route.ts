// GET /api/read-models/:view — Phase 6 cross-entity read-models (docs/jarvis-90-
// execution-blueprint.md §6), exposed directly so the dealer console (or any future
// dashboard) can query the same real, typed views workflow 6's daily digest already
// consumes — one query per named view, no LLM involved.

import { requireContext, errorResponse, AuthError } from "../../../../lib/auth";
import {
  reliability,
  readinessTrend,
  readinessSloScorecard,
  failureInjectionLog,
  workCases,
  workCasesPage,
  workforceStatus,
  executeAttentionQueueQuery,
} from "@finnor/read-models";
import { getProjection } from "@finnor/projections";
import { PeDomainError, peTransaction, type PeMutationContext } from "@finnor/private-equity";

async function requirePrivateEquityProduct(ctx: PeMutationContext["auth"]): Promise<void> {
  // P8 owns the active-product authority. Reuse that exact transactional guard
  // before exposing P9's unrooted firm attention/workforce views; otherwise a
  // tenant that has not been cut over can leak legacy Work into the PE shell.
  await peTransaction({ auth: ctx }, async () => undefined, { readOnly: true });
}

const VIEWS: Record<string, (tenantId: string, searchParams: URLSearchParams) => Promise<unknown>> = {
  // B1.T3: these 3 are served from the CQRS cache (self-healing on a cold miss), not
  // recomputed on every request — see packages/projections. windowDays on reliability
  // is ignored by the cached path (the cache is always the default 1-day window);
  // pass windowDays to opt into a live, uncached computation instead.
  "activity-snapshot": (tenantId) => getProjection(tenantId, "activity-snapshot"),
  "reliability": (tenantId, searchParams) => {
    const windowDays = Number(searchParams.get("windowDays") ?? 1);
    if (searchParams.has("windowDays") && Number.isFinite(windowDays) && windowDays > 0 && windowDays !== 1) {
      return reliability(tenantId, windowDays);
    }
    return getProjection(tenantId, "reliability");
  },
  // Backward-compatible registry entry; GET special-cases this view below to expose
  // its truthful bounded-page metadata alongside the unchanged data array.
  "work-cases": (tenantId) => workCases(tenantId),
  // Phase 8 (§8.3): the 30-day certification trend the cockpit's scorecard panel reads.
  "readiness": (tenantId, searchParams) => {
    const days = Number(searchParams.get("days") ?? 30);
    return readinessTrend(tenantId, Number.isFinite(days) && days > 0 ? days : 30);
  },
  "readiness-slo": (tenantId) => readinessSloScorecard(tenantId),
  // Phase 8 (§8.2): the failure-injection calendar's real log.
  "failure-injections": (tenantId) => failureInjectionLog(tenantId),
  "workforce-status": (tenantId, searchParams) => {
    const rawLimit = searchParams.get("limit");
    const cursor = searchParams.get("cursor") ?? undefined;
    const limit = rawLimit === null ? undefined : Number(rawLimit);
    return workforceStatus(tenantId, { page: limit === undefined && cursor === undefined ? undefined : { ...(limit === undefined ? {} : { limit }), ...(cursor === undefined ? {} : { cursor }) } });
  },
};

export async function GET(req: Request, { params }: { params: Promise<{ view: string }> }): Promise<Response> {
  try {
    const ctx = await requireContext(req);
    const { view } = await params;
    const searchParams = new URL(req.url).searchParams;
    if (view === "attention" || view === "workforce-status") {
      await requirePrivateEquityProduct(ctx);
    }
    if (view === "attention") {
      const requested = Number(searchParams.get("limit") ?? 100);
      const limit = Number.isFinite(requested) ? Math.min(100, Math.max(1, Math.floor(requested))) : 100;
      const data = await executeAttentionQueueQuery(
        ctx.tenantId,
        { intent: "attention_queue", page: { limit } },
        { employeeId: ctx.employeeId, userId: ctx.userId, verticalKey: "private_equity", maxRows: limit },
        new Date(),
      );
      return Response.json({ view, data }, { headers: { "Cache-Control": "private, no-store" } });
    }
    const fn = VIEWS[view];
    if (!fn) {
      return Response.json({ error: `Unknown read-model "${view}". Valid views: ${Object.keys(VIEWS).join(", ")}` }, { status: 404 });
    }
    if (view === "work-cases") {
      const rawLimit = searchParams.get("limit");
      const limit = rawLimit === null ? undefined : Number(rawLimit);
      const result = await workCasesPage(ctx.tenantId, { limit, cursor: searchParams.get("cursor") ?? undefined });
      return Response.json({ view, data: result.items, page: result.page });
    }
    const data = await fn(ctx.tenantId, searchParams);
    return Response.json({ view, data });
  } catch (err) {
    if (err instanceof PeDomainError) {
      return Response.json(
        { error: err.message, code: err.code, details: err.details },
        { status: 422, headers: { "Cache-Control": "private, no-store" } },
      );
    }
    return errorResponse(err);
  }
}
