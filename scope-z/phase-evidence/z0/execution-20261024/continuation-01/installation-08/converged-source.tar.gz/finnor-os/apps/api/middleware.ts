// Edge middleware: CORS for the console origin + cheap auth shape check. Real auth +
// tenant resolution happens in lib/auth.ts inside route handlers (needs Postgres,
// which the edge runtime cannot reach).

import { NextResponse, type NextRequest } from "next/server";

const ALLOWED_ORIGINS = (process.env.CONSOLE_ORIGIN ?? "http://localhost:3101")
  .split(",")
  .map((o) => o.trim());

function corsHeaders(requestOrigin: string | null): Record<string, string> {
  const origin = requestOrigin && ALLOWED_ORIGINS.includes(requestOrigin) ? requestOrigin : ALLOWED_ORIGINS[0]!;
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "authorization, content-type, x-tenant-id, x-user-id, x-user-role",
    "Access-Control-Max-Age": "86400",
  };
}

export function middleware(req: NextRequest) {
  const origin = req.headers.get("origin");
  if (req.method === "OPTIONS") {
    return new NextResponse(null, { status: 204, headers: corsHeaders(origin) });
  }
  const isWebhook =
    req.nextUrl.pathname.startsWith("/api/webhooks/") ||
    req.nextUrl.pathname.startsWith("/api/admin/") || // admin routes carry their own ADMIN_SECRET check
    req.nextUrl.pathname === "/api/connections/google/callback"; // signed state + PKCE + one-time DB claim
  // Release provenance and liveness are deliberately anonymous. Keep this
  // boundary aligned with their route handlers so platform middleware cannot
  // turn a healthy deployment into an apparent 401 before either handler runs.
  const isPublicReadiness = req.nextUrl.pathname === "/api/release" || req.nextUrl.pathname === "/api/health" || req.nextUrl.pathname === "/api/ready";
  const hasAuth =
    req.headers.has("authorization") ||
    // Same NODE_ENV gate as lib/auth.ts's requireContext(): a misconfigured prod deploy
    // that left AUTH_DEV_BYPASS=1 set must not accept forged x-tenant-id headers here
    // either — this shape check must not be laxer than the real auth it fronts.
    (process.env.AUTH_DEV_BYPASS === "1" && process.env.NODE_ENV !== "production" && req.headers.has("x-tenant-id"));
  if (!isWebhook && !isPublicReadiness && !hasAuth) {
    return NextResponse.json(
      { error: "Missing Authorization header" },
      { status: 401, headers: corsHeaders(origin) },
    );
  }
  const res = NextResponse.next();
  for (const [k, v] of Object.entries(corsHeaders(origin))) res.headers.set(k, v);
  return res;
}

export const config = { matcher: "/api/:path*" };
