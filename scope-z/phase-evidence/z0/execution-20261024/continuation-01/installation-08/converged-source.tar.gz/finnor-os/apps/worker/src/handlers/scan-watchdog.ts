// scan_watchdog job (A4.T2, CENTROPY MAESTRO PLAN §4): four independent reliability
// signals the existing scans don't cover — stuck runs, orphaned steps, aging approvals
// (nudge only), and unfinalized receipts. Modeled directly on scan-reliability-alerts.ts's
// split between a pure, unit-testable detector and a thin handler that reports/acts —
// same convention, new signals.
//
// Deliberately NOT duplicated here (grep-before-build, hard rule #29):
//  - lease-expired step recovery — packages/workflow-runtime/src/steps.ts's
//    recoverStaleSteps() already re-enqueues/reconciles those; this scan only catches a
//    DIFFERENT gap it can't: a step stuck "pending" because its own enqueue job-insert
//    never happened (crash between the step row and the job row), which never has a
//    lease to expire in the first place.
//  - approval expiry — scan-approval-expiry.ts already escalates a pending action past
//    its full confirmationTimeoutHours to needs_human_review. This scan's aging-approval
//    signal fires EARLIER (half that timeout) and only nudges — never changes status —
//    so it can't race or duplicate that scan's own transition.

import { MAX_BACKGROUND_SCAN_BATCH, withTenant, workflowRuns, workflowSteps, decisionReceipts, domainActions, domainPolicies, domainPolicyRevisions, enqueueJob, getPool } from "@finnor/db";
import { and, asc, eq, gt, lt, isNull, or, sql } from "drizzle-orm";
import { enqueueStep } from "@finnor/workflow-runtime/steps";
import { isRunPastWatchdogDeadline, stuckRunDeadlineHours } from "@finnor/workflow-runtime/stuck-runs";
import { workflowStepJobKey } from "@finnor/workflow-runtime/job-identity";
import { appendEpisode, readEpisodes } from "@finnor/memory/episodic";
import { recoverStaleProviderOperations, Sentry } from "@finnor/tools";
import type { JobHandler } from "../queue";

// Conservative first-pass thresholds, not fabricated p95s. Active product single-action
// runs get a short bound; any future active multi-step workflow uses the shared default
// until measured production history justifies a named threshold.
const ORPHANED_STEP_MINUTES = 10;
const UNFINALIZED_RECEIPT_MINUTES = 60;
// Half of scan-approval-expiry's own default — a nudge should land well before the
// escalation it's warning about, not right on top of it.
const AGING_APPROVAL_NUDGE_FRACTION = 0.5;

export interface WatchdogFinding {
  kind: "stuck_run" | "orphaned_step" | "unfinalized_receipt" | "aging_approval_nudge" | "stale_provider_operation";
  tenantId: string;
  refId: string;
  domainActionId?: string;
  detail: Record<string, unknown>;
}

function hoursSince(d: Date): number {
  return (Date.now() - d.getTime()) / 3_600_000;
}

async function detectStuckRuns(tenantId: string): Promise<WatchdogFinding[]> {
  const running = await withTenant(tenantId, (db) =>
    db.select().from(workflowRuns).where(and(eq(workflowRuns.tenantId, tenantId), eq(workflowRuns.status, "running"))),
  );
  const findings: WatchdogFinding[] = [];
  for (const run of running) {
    const deadline = stuckRunDeadlineHours(run.workflowType);
    const elapsed = hoursSince(run.updatedAt);
    if (isRunPastWatchdogDeadline(run)) {
      findings.push({
        kind: "stuck_run",
        tenantId,
        refId: run.id,
        detail: { workflowType: run.workflowType, elapsedHours: Math.round(elapsed * 10) / 10, deadlineHours: deadline },
      });
    }
  }
  return findings;
}

/** A pending step is healthy only while its current-generation job is actionable.
 * Completed/failed/dead-letter rows are historical evidence, not future delivery;
 * enqueueStep advances the generation and creates the replacement atomically. */
async function detectAndHealOrphanedSteps(tenantId: string): Promise<WatchdogFinding[]> {
  const cutoff = new Date(Date.now() - ORPHANED_STEP_MINUTES * 60_000);
  const pending = await withTenant(tenantId, (db) =>
    db
      .select()
      .from(workflowSteps)
      .where(and(eq(workflowSteps.tenantId, tenantId), eq(workflowSteps.status, "pending"), lt(workflowSteps.createdAt, cutoff))),
  );
  if (pending.length === 0) return [];

  const findings: WatchdogFinding[] = [];
  for (const step of pending) {
    const canonicalJobKey = workflowStepJobKey(tenantId, step.id, step.dispatchGeneration);
    const { rows } = await getPool().query<{ status: string }>("SELECT status FROM jobs WHERE idempotency_key = $1 LIMIT 1", [canonicalJobKey]);
    const jobStatuses = rows.map((row) => row.status);
    if (jobStatuses.some((status) => status === "queued" || status === "running")) continue;
    findings.push({
      kind: "orphaned_step",
      tenantId,
      refId: step.id,
      domainActionId: step.domainActionId ?? undefined,
      detail: { stepType: step.stepType, ageMinutes: Math.round(hoursSince(step.createdAt) * 60), jobStatuses },
    });
    await enqueueStep(tenantId, step.id, step.idempotencyKey);
  }
  return findings;
}

async function detectUnfinalizedReceipts(tenantId: string): Promise<WatchdogFinding[]> {
  const cutoff = new Date(Date.now() - UNFINALIZED_RECEIPT_MINUTES * 60_000);
  const stale = await withTenant(tenantId, (db) =>
    db
      .select()
      .from(decisionReceipts)
      .where(and(eq(decisionReceipts.tenantId, tenantId), isNull(decisionReceipts.finalizedAt), lt(decisionReceipts.createdAt, cutoff))),
  );
  return stale.map((r) => ({
    kind: "unfinalized_receipt" as const,
    tenantId,
    refId: r.id,
    domainActionId: r.domainActionId ?? undefined,
    detail: { objective: r.objective, ageMinutes: Math.round(hoursSince(r.createdAt) * 60) },
  }));
}

async function recoverAbandonedProviderOperations(tenantId: string): Promise<WatchdogFinding[]> {
  const recovery = await recoverStaleProviderOperations(tenantId);
  return recovery.operationIds.map((operationId) => ({
    kind: "stale_provider_operation" as const,
    tenantId,
    refId: operationId,
    detail: {
      inspected: recovery.inspected,
      knownFailedBeforeEgress: recovery.knownFailedBeforeEgress,
      acknowledgementResumed: recovery.acknowledgementResumed,
      reconciliationRequired: recovery.reconciliationRequired,
    },
  }));
}

/** Nudge only — never touches domain_actions.status (scan-approval-expiry.ts owns that
 *  transition). Deduped via an action_log episode so a tenant's pending action gets
 *  exactly one nudge, not one per scan tick until it either clears or expires. */
async function detectAndNudgeAgingApprovals(tenantId: string): Promise<WatchdogFinding[]> {
  const findings: WatchdogFinding[] = [];
  let cursor: { createdAt: Date; id: string } | null = null;
  while (true) {
    const pendingPlus = await withTenant(tenantId, (db) =>
      db
        .select({
          id: domainActions.id,
          actionType: domainActions.actionType,
          createdAt: domainActions.createdAt,
          summary: domainActions.summary,
          confirmationTimeoutHours: domainPolicyRevisions.confirmationTimeoutHours,
          legacyConfirmationTimeoutHours: domainPolicies.confirmationTimeoutHours,
        })
        .from(domainActions)
        .leftJoin(domainPolicyRevisions, and(
          eq(domainActions.policyId, domainPolicyRevisions.policyId),
          eq(domainActions.policyVersion, domainPolicyRevisions.version),
        ))
        .leftJoin(domainPolicies, eq(domainActions.policyId, domainPolicies.id))
        .where(and(
          eq(domainActions.tenantId, tenantId),
          eq(domainActions.status, "pending"),
          cursor ? or(
            gt(domainActions.createdAt, cursor.createdAt),
            and(eq(domainActions.createdAt, cursor.createdAt), gt(domainActions.id, cursor.id)),
          ) : undefined,
        ))
        .orderBy(asc(domainActions.createdAt), asc(domainActions.id))
        .limit(MAX_BACKGROUND_SCAN_BATCH + 1),
    );
    const pending = pendingPlus.slice(0, MAX_BACKGROUND_SCAN_BATCH);
    for (const row of pending) {
      const timeoutHours = row.confirmationTimeoutHours ?? row.legacyConfirmationTimeoutHours ?? 24;
      const nudgeAtHours = timeoutHours * AGING_APPROVAL_NUDGE_FRACTION;
      if (hoursSince(row.createdAt) < nudgeAtHours) continue;

      const episodes = await readEpisodes(tenantId, { domainActionId: row.id, limit: 50 });
      if (episodes.some((e) => e.step === "watchdog_nudge_sent")) continue; // already nudged once

      findings.push({
        kind: "aging_approval_nudge",
        tenantId,
        refId: row.id,
        domainActionId: row.id,
        detail: { actionType: row.actionType, timeoutHours, nudgeAtHours: Math.round(nudgeAtHours * 10) / 10 },
      });
      await appendEpisode(tenantId, row.id, "watchdog_nudge_sent", {}, { nudgeAtHours });
      // The durable attention item is already visible. Scope 2 retired the direct
      // voice nudge because it had no logical provider-operation owner.
    }
    if (pending.length === 0) break;
    const last = pending.at(-1);
    if (pendingPlus.length <= MAX_BACKGROUND_SCAN_BATCH || !last) break;
    cursor = { createdAt: last.createdAt, id: last.id };
  }
  return findings;
}

/** Pure(ish) detector — the orphaned-step branch does self-heal (re-enqueue) inline since
 *  that IS the finding's remediation, same posture as recoverStaleSteps' own "no claim row
 *  yet: safe to reset and re-enqueue" branch. Everything else here only reads + reports;
 *  the handler below is the thin, untested-by-design wiring that alerts on it. */
export async function detectWatchdogFindings(tenantId: string): Promise<WatchdogFinding[]> {
  const [stuckRuns, orphanedSteps, unfinalizedReceipts, agingNudges, staleProviderOperations] = await Promise.all([
    detectStuckRuns(tenantId),
    detectAndHealOrphanedSteps(tenantId),
    detectUnfinalizedReceipts(tenantId),
    detectAndNudgeAgingApprovals(tenantId),
    recoverAbandonedProviderOperations(tenantId),
  ]);
  return [...stuckRuns, ...orphanedSteps, ...unfinalizedReceipts, ...agingNudges, ...staleProviderOperations];
}

function severityFor(kind: WatchdogFinding["kind"]): "warning" | "error" {
  // A stuck run or an unfinalized receipt is a real reliability defect worth paging on;
  // an orphaned step self-heals the moment this scan finds it, and a nudge is routine —
  // both stay at "warning" (visible, not urgent).
  return kind === "stuck_run" || kind === "stale_provider_operation" ? "error" : "warning";
}

export const scanWatchdog: JobHandler = async (payload) => {
  const tenantId = String(payload.tenantId ?? "");
  if (!tenantId) throw new Error("scan_watchdog requires tenantId");

  const findings = await detectWatchdogFindings(tenantId);
  for (const finding of findings) {
    // The approval record and watchdog episode are the durable attention surface.
    // Scope 2 intentionally retired the untracked voice-provider mutation.
    if (finding.kind === "aging_approval_nudge") continue;
    Sentry.captureMessage(`watchdog:${finding.kind}:tenant:${tenantId}`, {
      level: severityFor(finding.kind),
      extra: finding.detail,
      tags: { watchdog_kind: finding.kind, tenant_id: tenantId },
    });
    if (finding.domainActionId) {
      await appendEpisode(tenantId, finding.domainActionId, "watchdog_finding", {}, { kind: finding.kind, ...finding.detail }).catch(() => undefined);
    }
  }
};
