// SIMULATED fixture
